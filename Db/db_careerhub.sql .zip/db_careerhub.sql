-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 12, 2024 at 05:47 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `db_careerhub`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_admin`
--

CREATE TABLE `tbl_admin` (
  `admin_id` int(11) NOT NULL auto_increment,
  `admin_name` varchar(50) NOT NULL,
  `admin_email` varchar(50) NOT NULL,
  `admin_password` varchar(50) NOT NULL,
  `admin_contact` varchar(10) NOT NULL,
  PRIMARY KEY  (`admin_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `tbl_admin`
--

INSERT INTO `tbl_admin` (`admin_id`, `admin_name`, `admin_email`, `admin_password`, `admin_contact`) VALUES
(1, 'Basith', 'abdulbasith9063@gmail.com', '24680', '9605899537'),
(2, 'Ebrahim Badusha', 'eb5121084@gmail.com', '123456789', '8156802127');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_application`
--

CREATE TABLE `tbl_application` (
  `application_id` int(11) NOT NULL auto_increment,
  `application_date` date NOT NULL,
  `job_id` int(11) NOT NULL,
  `jobseeker_id` int(11) NOT NULL,
  PRIMARY KEY  (`application_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `tbl_application`
--

INSERT INTO `tbl_application` (`application_id`, `application_date`, `job_id`, `jobseeker_id`) VALUES
(4, '2024-10-23', 3, 4),
(5, '2024-10-23', 4, 6),
(6, '2024-10-23', 5, 5),
(7, '2024-10-31', 3, 5),
(8, '2024-10-31', 3, 5),
(9, '2024-10-31', 3, 5),
(10, '2024-10-31', 3, 5),
(11, '2024-10-31', 3, 5);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_booking`
--

CREATE TABLE `tbl_booking` (
  `booking_id` int(11) NOT NULL auto_increment,
  `booking_date` varchar(100) NOT NULL,
  `booking_status` int(20) NOT NULL default '0',
  `jobseeker_id` int(11) NOT NULL,
  `booking_amount` varchar(100) NOT NULL,
  PRIMARY KEY  (`booking_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_booking`
--

INSERT INTO `tbl_booking` (`booking_id`, `booking_date`, `booking_status`, `jobseeker_id`, `booking_amount`) VALUES
(5, '2024-11-04', 1, 5, '10000/-'),
(6, '2024-11-04', 1, 5, '5000/-');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_companytype`
--

CREATE TABLE `tbl_companytype` (
  `companytype_id` int(11) NOT NULL auto_increment,
  `companytype_name` varchar(50) NOT NULL,
  PRIMARY KEY  (`companytype_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_companytype`
--

INSERT INTO `tbl_companytype` (`companytype_id`, `companytype_name`) VALUES
(4, 'Startup'),
(5, 'Corporate'),
(6, 'Indian MNC'),
(7, 'Foreign MNC'),
(8, 'Govt/PSU');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_complaint`
--

CREATE TABLE `tbl_complaint` (
  `complaint_id` int(11) NOT NULL auto_increment,
  `complaint_date` varchar(50) NOT NULL,
  `complaint_content` varchar(1000) NOT NULL,
  `complaint_reply` varchar(500) NOT NULL,
  `complaint_status` int(50) NOT NULL default '0',
  `jobprovider_id` int(11) NOT NULL,
  `jobseeker_id` int(11) NOT NULL,
  `complaint_title` varchar(1000) NOT NULL,
  PRIMARY KEY  (`complaint_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `tbl_complaint`
--

INSERT INTO `tbl_complaint` (`complaint_id`, `complaint_date`, `complaint_content`, `complaint_reply`, `complaint_status`, `jobprovider_id`, `jobseeker_id`, `complaint_title`) VALUES
(4, '2024-10-26', 'good', 'dsadasdd', 1, 0, 6, 'gg'),
(5, '2024-10-26', 'edqwqwq', 'dfsdfsdfs', 1, 0, 5, 'edwdw');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_department`
--

CREATE TABLE `tbl_department` (
  `department_id` int(11) NOT NULL auto_increment,
  `department_name` varchar(100) NOT NULL,
  `jobprovider_id` int(11) NOT NULL,
  PRIMARY KEY  (`department_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=37 ;

--
-- Dumping data for table `tbl_department`
--

INSERT INTO `tbl_department` (`department_id`, `department_name`, `jobprovider_id`) VALUES
(22, 'Technology', 10),
(24, 'Data Science &Analysis', 10),
(26, 'Engineering -Software', 10),
(27, 'Engineering -Hardware', 10),
(28, 'Sales & Business Development', 10),
(29, 'Human Resources', 10),
(30, 'Research & Development', 10),
(31, 'Consulting', 10),
(34, 'Sales & Business Development', 11),
(35, 'Sales & Business Development', 11),
(36, 'Manufacturing and Engineering', 11);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_district`
--

CREATE TABLE `tbl_district` (
  `district_id` int(11) NOT NULL auto_increment,
  `district_name` varchar(50) NOT NULL,
  `state_id` int(11) NOT NULL,
  PRIMARY KEY  (`district_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `tbl_district`
--

INSERT INTO `tbl_district` (`district_id`, `district_name`, `state_id`) VALUES
(4, 'kashmir', 9),
(5, 'jammu', 9),
(6, 'kollam', 1),
(8, 'Ernakulam', 1),
(9, 'Vishakapattanam', 13),
(10, 'Chittoor', 13),
(12, 'Baksa', 14),
(13, 'Jorhat', 14),
(16, 'South Goa', 15),
(17, 'Ambala', 16),
(19, 'North Delhi', 18),
(20, 'South Delhi', 18),
(23, 'Jalandhar', 10),
(24, 'Mansa', 10),
(25, 'Coimbatore', 11),
(26, 'Chennai', 11),
(27, 'Bengaluru', 19);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_feedback`
--

CREATE TABLE `tbl_feedback` (
  `feedback_id` int(11) NOT NULL auto_increment,
  `feedback_content` varchar(100) NOT NULL,
  `feedback_status` int(11) NOT NULL,
  `feedback_replay` varchar(500) NOT NULL,
  `jobprovider_id` int(11) NOT NULL,
  `jobseeker_id` int(11) NOT NULL,
  `feedback_date` date NOT NULL,
  PRIMARY KEY  (`feedback_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `tbl_feedback`
--

INSERT INTO `tbl_feedback` (`feedback_id`, `feedback_content`, `feedback_status`, `feedback_replay`, `jobprovider_id`, `jobseeker_id`, `feedback_date`) VALUES
(2, 'Good Website', 1, 'Thanks\r\n', 0, 4, '2024-10-16'),
(3, 'badd!!!', 1, 'our panter is looking for best interface', 0, 6, '2024-10-30');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_industry`
--

CREATE TABLE `tbl_industry` (
  `industry_id` int(11) NOT NULL auto_increment,
  `industry_name` varchar(100) NOT NULL,
  PRIMARY KEY  (`industry_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `tbl_industry`
--

INSERT INTO `tbl_industry` (`industry_id`, `industry_name`) VALUES
(3, 'IT'),
(5, 'Helthcare'),
(6, 'Banking'),
(7, 'Education/Training'),
(8, 'Real Estate'),
(9, 'Iron & Steel'),
(10, 'Automobile');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_interview`
--

CREATE TABLE `tbl_interview` (
  `interview_id` int(11) NOT NULL auto_increment,
  `interview_type` varchar(50) NOT NULL,
  `interview_details` varchar(50) NOT NULL,
  `interview_time` varchar(50) NOT NULL,
  `application_id` int(11) NOT NULL,
  `place_id` int(11) NOT NULL,
  PRIMARY KEY  (`interview_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_interview`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_job`
--

CREATE TABLE `tbl_job` (
  `job_id` int(11) NOT NULL auto_increment,
  `job_name` varchar(50) NOT NULL,
  `job_post_date` varchar(100) NOT NULL,
  `jobsubcategory_id` int(100) NOT NULL,
  `job_vacancy` varchar(50) NOT NULL,
  `job_work_hour` varchar(50) NOT NULL,
  `job_qualification` varchar(50) NOT NULL,
  `job_experience` varchar(50) NOT NULL,
  `job_salary` varchar(50) NOT NULL,
  `job_about` varchar(50) NOT NULL,
  `job_last_date` date NOT NULL,
  `industry_id` int(11) NOT NULL,
  PRIMARY KEY  (`job_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_job`
--

INSERT INTO `tbl_job` (`job_id`, `job_name`, `job_post_date`, `jobsubcategory_id`, `job_vacancy`, `job_work_hour`, `job_qualification`, `job_experience`, `job_salary`, `job_about`, `job_last_date`, `industry_id`) VALUES
(3, 'UX/UI Design', '2024-10-09', 4, '3', '8', 'Bsc.Comp/BCA/Master in any computer science', '0-5 years', '30000', 'about the job', '2024-10-12', 3),
(4, 'Engineer Trainee', '2024-10-23', 7, '2', '8', 'B.Tech/B.E.in Mechanical', 'Fresher', '2.5 - 3.5 LPA', 'bla bla bla', '2024-11-02', 9),
(5, 'UX/UI Design', '2024-10-23', 7, '3', '8', 'Bsc.Comp/BCA/Master in any computer science', '0-5 years', '2.5 - 3.5 LPA', 'ubuikljhb', '2024-11-09', 6),
(6, 'ddfsdf', '2024-10-31', 7, '3', '23', 'fsdfsdf', '3', '129999', 'fdsfsdfsfsfds', '2024-10-16', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jobcategory`
--

CREATE TABLE `tbl_jobcategory` (
  `jobcategory_id` int(11) NOT NULL auto_increment,
  `jobcategory_name` varchar(100) NOT NULL,
  `department_id` int(11) NOT NULL,
  PRIMARY KEY  (`jobcategory_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `tbl_jobcategory`
--

INSERT INTO `tbl_jobcategory` (`jobcategory_id`, `jobcategory_name`, `department_id`) VALUES
(4, 'Architecture', 25),
(5, 'Data Analyst', 24),
(6, 'Testing', 22),
(7, 'Associate /Consultant', 31),
(8, 'Engineering', 36);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jobprovider`
--

CREATE TABLE `tbl_jobprovider` (
  `jobprovider_id` int(11) NOT NULL auto_increment,
  `district_id` int(11) NOT NULL,
  `companytype_id` int(11) NOT NULL,
  `jobprovider_name` varchar(50) NOT NULL,
  `jobprovider_email` varchar(50) NOT NULL,
  `jobprovider_place` varchar(100) NOT NULL,
  `jobprovider_password` varchar(50) NOT NULL,
  `jobprovider_contact` varchar(10) NOT NULL,
  `jobprovider_proof` varchar(50) NOT NULL,
  `jobprovider_status` int(50) NOT NULL default '0',
  `jobprovider_logo` varchar(50) NOT NULL,
  `jobprovider_web_add` varchar(50) NOT NULL,
  PRIMARY KEY  (`jobprovider_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `tbl_jobprovider`
--

INSERT INTO `tbl_jobprovider` (`jobprovider_id`, `district_id`, `companytype_id`, `jobprovider_name`, `jobprovider_email`, `jobprovider_place`, `jobprovider_password`, `jobprovider_contact`, `jobprovider_proof`, `jobprovider_status`, `jobprovider_logo`, `jobprovider_web_add`) VALUES
(11, 9, 5, 'Indian Steel Pvt.Ltd', 'indanstell345@gmail.com', 'Vadlapudi', 'indanstell345', '123456', 'wp5231544-4k-gaming-wallpapers.jpg', 1, 'sru.png', 'www.indiansteel.com'),
(12, 19, 7, 'Adidas', 'adids96@gmail.com', 'New Delhi', 'adids96', '9876546321', 'suhail.png', 1, 'wp5231544-4k-gaming-wallpapers.jpg', 'www.adidas.com');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jobseeker`
--

CREATE TABLE `tbl_jobseeker` (
  `jobseeker_id` int(11) NOT NULL auto_increment,
  `jobseeker_name` varchar(50) NOT NULL,
  `jobseeker_email` varchar(50) NOT NULL,
  `jobseeker_password` varchar(50) NOT NULL,
  `jobseeker_contact` varchar(10) NOT NULL,
  `jobseeker_education` varchar(50) NOT NULL,
  `jobseeker_experience` varchar(50) NOT NULL,
  `jobseeker_previousjob` varchar(50) NOT NULL,
  `jobseeker_photo` varchar(50) NOT NULL,
  `jobseeker_resume` varchar(50) NOT NULL,
  `jobseeker_address` varchar(50) NOT NULL,
  `jobseeker_gender` varchar(50) NOT NULL,
  `jobseeker_status` int(11) NOT NULL,
  `district_id` int(11) NOT NULL,
  `jobseeker_place` varchar(50) NOT NULL,
  PRIMARY KEY  (`jobseeker_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `tbl_jobseeker`
--

INSERT INTO `tbl_jobseeker` (`jobseeker_id`, `jobseeker_name`, `jobseeker_email`, `jobseeker_password`, `jobseeker_contact`, `jobseeker_education`, `jobseeker_experience`, `jobseeker_previousjob`, `jobseeker_photo`, `jobseeker_resume`, `jobseeker_address`, `jobseeker_gender`, `jobseeker_status`, `district_id`, `jobseeker_place`) VALUES
(5, 'abin123', 'abin123@gmail.com', 'abin123', '9876543210', 'BCA', '2 year', 'System analysis', 'suahil on the way.png', 'suhail.png', 'dgzjfchs', 'Male', 1, 8, 'vytila'),
(6, 'Abdul Basith', 'abdulnbasith9063@gmail.com', '13579', '9876543210', 'BCA', 'Fresher', 'Nil', 'wp5231544-4k-gaming-wallpapers.jpg', 'suhail.png', 'Abc Udumbannoor', 'Male', 1, 8, 'Muvattupuzha');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_jobsubcategory`
--

CREATE TABLE `tbl_jobsubcategory` (
  `jobsubcategory_id` int(11) NOT NULL auto_increment,
  `jobsubcategory_name` varchar(50) NOT NULL,
  `jobcategory_id` int(11) NOT NULL,
  PRIMARY KEY  (`jobsubcategory_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tbl_jobsubcategory`
--

INSERT INTO `tbl_jobsubcategory` (`jobsubcategory_id`, `jobsubcategory_name`, `jobcategory_id`) VALUES
(1, 'Senior Analyst', 3),
(3, 'Senior Analyst', 5),
(4, 'Game testing', 6),
(5, 'Civil', 4),
(6, 'Management  Consulting', 7),
(7, 'Mechanical Engineering', 8);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_premiumcard`
--

CREATE TABLE `tbl_premiumcard` (
  `card_id` int(11) NOT NULL auto_increment,
  `card_title` varchar(100) NOT NULL,
  `card_description` varchar(100) NOT NULL,
  `card_image_url` varchar(1000) NOT NULL,
  `card_status` int(20) NOT NULL default '0',
  `booking_id` int(11) NOT NULL,
  PRIMARY KEY  (`card_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `tbl_premiumcard`
--

INSERT INTO `tbl_premiumcard` (`card_id`, `card_title`, `card_description`, `card_image_url`, `card_status`, `booking_id`) VALUES
(15, 'Technical Skills', 'This card is designed with a luxurious feel in mind, combining gradients, subtle shadows, and elegan', 'https://images.pexels.com/photos/5496464/pexels-photo-5496464.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', 1, 5),
(16, 'Interpersonal Skills', 'This card is designed with a luxurious feel in mind, combining gradients, subtle shadows, and elegan', 'https://images.pexels.com/photos/3182834/pexels-photo-3182834.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=2', 1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ranking`
--

CREATE TABLE `tbl_ranking` (
  `ranking_id` int(11) NOT NULL auto_increment,
  `ranking_rating` int(11) NOT NULL,
  `feedback_id` int(11) NOT NULL,
  `jobprovider_id` int(11) NOT NULL,
  PRIMARY KEY  (`ranking_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `tbl_ranking`
--


-- --------------------------------------------------------

--
-- Table structure for table `tbl_state`
--

CREATE TABLE `tbl_state` (
  `state_id` int(11) NOT NULL auto_increment,
  `state_name` varchar(50) NOT NULL,
  PRIMARY KEY  (`state_id`),
  UNIQUE KEY `state_name` (`state_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `tbl_state`
--

INSERT INTO `tbl_state` (`state_id`, `state_name`) VALUES
(13, 'Andha Pradesh'),
(14, 'Assam'),
(15, 'Goa'),
(16, 'Haryana'),
(19, 'Karnataka'),
(1, 'Kerala'),
(18, 'New Delhi'),
(17, 'Odisha'),
(11, 'Tamil Nadu');
